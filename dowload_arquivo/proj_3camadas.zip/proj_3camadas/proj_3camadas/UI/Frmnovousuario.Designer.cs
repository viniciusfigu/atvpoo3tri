﻿
namespace proj_3camadas.UI
{
    partial class Frmnovousuario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.lblnome = new System.Windows.Forms.Label();
            this.txtnome = new System.Windows.Forms.TextBox();
            this.lbltelefone = new System.Windows.Forms.Label();
            this.txttelefone = new System.Windows.Forms.TextBox();
            this.lblrua = new System.Windows.Forms.Label();
            this.txtrua = new System.Windows.Forms.TextBox();
            this.lbnumero = new System.Windows.Forms.Label();
            this.txtnumero = new System.Windows.Forms.TextBox();
            this.lblbairro = new System.Windows.Forms.Label();
            this.txtbairro = new System.Windows.Forms.TextBox();
            this.lblcidade = new System.Windows.Forms.Label();
            this.txtcidade = new System.Windows.Forms.TextBox();
            this.lblestado = new System.Windows.Forms.Label();
            this.txtestado = new System.Windows.Forms.TextBox();
            this.lblCountry = new System.Windows.Forms.Label();
            this.txtcountry = new System.Windows.Forms.TextBox();
            this.lblcpf = new System.Windows.Forms.Label();
            this.txtCPF = new System.Windows.Forms.TextBox();
            this.lblrg = new System.Windows.Forms.Label();
            this.txtrg = new System.Windows.Forms.TextBox();
            this.lbldatanascimento = new System.Windows.Forms.Label();
            this.txtdatanascimento = new System.Windows.Forms.TextBox();
            this.lblpais = new System.Windows.Forms.Label();
            this.txtpais = new System.Windows.Forms.TextBox();
            this.lblemail = new System.Windows.Forms.Label();
            this.txtemail = new System.Windows.Forms.TextBox();
            this.lblsenha = new System.Windows.Forms.Label();
            this.txtsenha = new System.Windows.Forms.TextBox();
            this.btncadastrar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(96, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(153, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Cadastro de novos Usuários";
            // 
            // lblnome
            // 
            this.lblnome.AutoSize = true;
            this.lblnome.Location = new System.Drawing.Point(12, 83);
            this.lblnome.Name = "lblnome";
            this.lblnome.Size = new System.Drawing.Size(43, 15);
            this.lblnome.TabIndex = 1;
            this.lblnome.Text = "Nome:";
            // 
            // txtnome
            // 
            this.txtnome.Location = new System.Drawing.Point(12, 100);
            this.txtnome.Multiline = true;
            this.txtnome.Name = "txtnome";
            this.txtnome.Size = new System.Drawing.Size(111, 25);
            this.txtnome.TabIndex = 2;
            // 
            // lbltelefone
            // 
            this.lbltelefone.AutoSize = true;
            this.lbltelefone.Location = new System.Drawing.Point(140, 82);
            this.lbltelefone.Name = "lbltelefone";
            this.lbltelefone.Size = new System.Drawing.Size(54, 15);
            this.lbltelefone.TabIndex = 3;
            this.lbltelefone.Text = "Telefone:";
            // 
            // txttelefone
            // 
            this.txttelefone.Location = new System.Drawing.Point(140, 101);
            this.txttelefone.Multiline = true;
            this.txttelefone.Name = "txttelefone";
            this.txttelefone.Size = new System.Drawing.Size(100, 23);
            this.txttelefone.TabIndex = 4;
            // 
            // lblrua
            // 
            this.lblrua.AutoSize = true;
            this.lblrua.Location = new System.Drawing.Point(13, 152);
            this.lblrua.Name = "lblrua";
            this.lblrua.Size = new System.Drawing.Size(30, 15);
            this.lblrua.TabIndex = 5;
            this.lblrua.Text = "Rua:";
            // 
            // txtrua
            // 
            this.txtrua.Location = new System.Drawing.Point(13, 172);
            this.txtrua.Multiline = true;
            this.txtrua.Name = "txtrua";
            this.txtrua.Size = new System.Drawing.Size(100, 23);
            this.txtrua.TabIndex = 6;
            // 
            // lbnumero
            // 
            this.lbnumero.AutoSize = true;
            this.lbnumero.Location = new System.Drawing.Point(140, 152);
            this.lbnumero.Name = "lbnumero";
            this.lbnumero.Size = new System.Drawing.Size(54, 15);
            this.lbnumero.TabIndex = 7;
            this.lbnumero.Text = "Número:";
            this.lbnumero.Click += new System.EventHandler(this.label2_Click);
            // 
            // txtnumero
            // 
            this.txtnumero.Location = new System.Drawing.Point(140, 172);
            this.txtnumero.Multiline = true;
            this.txtnumero.Name = "txtnumero";
            this.txtnumero.Size = new System.Drawing.Size(100, 23);
            this.txtnumero.TabIndex = 8;
            // 
            // lblbairro
            // 
            this.lblbairro.AutoSize = true;
            this.lblbairro.Location = new System.Drawing.Point(259, 152);
            this.lblbairro.Name = "lblbairro";
            this.lblbairro.Size = new System.Drawing.Size(41, 15);
            this.lblbairro.TabIndex = 9;
            this.lblbairro.Text = "Bairro:";
            // 
            // txtbairro
            // 
            this.txtbairro.Location = new System.Drawing.Point(259, 172);
            this.txtbairro.Multiline = true;
            this.txtbairro.Name = "txtbairro";
            this.txtbairro.Size = new System.Drawing.Size(100, 23);
            this.txtbairro.TabIndex = 10;
            // 
            // lblcidade
            // 
            this.lblcidade.AutoSize = true;
            this.lblcidade.Location = new System.Drawing.Point(382, 153);
            this.lblcidade.Name = "lblcidade";
            this.lblcidade.Size = new System.Drawing.Size(47, 15);
            this.lblcidade.TabIndex = 11;
            this.lblcidade.Text = "Cidade:";
            // 
            // txtcidade
            // 
            this.txtcidade.Location = new System.Drawing.Point(382, 172);
            this.txtcidade.Multiline = true;
            this.txtcidade.Name = "txtcidade";
            this.txtcidade.Size = new System.Drawing.Size(100, 23);
            this.txtcidade.TabIndex = 12;
            // 
            // lblestado
            // 
            this.lblestado.AutoSize = true;
            this.lblestado.Location = new System.Drawing.Point(505, 153);
            this.lblestado.Name = "lblestado";
            this.lblestado.Size = new System.Drawing.Size(45, 15);
            this.lblestado.TabIndex = 13;
            this.lblestado.Text = "Estado:";
            // 
            // txtestado
            // 
            this.txtestado.Location = new System.Drawing.Point(505, 171);
            this.txtestado.Multiline = true;
            this.txtestado.Name = "txtestado";
            this.txtestado.Size = new System.Drawing.Size(100, 23);
            this.txtestado.TabIndex = 14;
            // 
            // lblCountry
            // 
            this.lblCountry.AutoSize = true;
            this.lblCountry.Location = new System.Drawing.Point(622, 153);
            this.lblCountry.Name = "lblCountry";
            this.lblCountry.Size = new System.Drawing.Size(31, 15);
            this.lblCountry.TabIndex = 15;
            this.lblCountry.Text = "País:";
            // 
            // txtcountry
            // 
            this.txtcountry.Location = new System.Drawing.Point(622, 172);
            this.txtcountry.Name = "txtcountry";
            this.txtcountry.Size = new System.Drawing.Size(100, 23);
            this.txtcountry.TabIndex = 16;
            // 
            // lblcpf
            // 
            this.lblcpf.AutoSize = true;
            this.lblcpf.Location = new System.Drawing.Point(262, 83);
            this.lblcpf.Name = "lblcpf";
            this.lblcpf.Size = new System.Drawing.Size(31, 15);
            this.lblcpf.TabIndex = 17;
            this.lblcpf.Text = "CPF:";
            // 
            // txtCPF
            // 
            this.txtCPF.Location = new System.Drawing.Point(262, 101);
            this.txtCPF.Name = "txtCPF";
            this.txtCPF.Size = new System.Drawing.Size(100, 23);
            this.txtCPF.TabIndex = 18;
            // 
            // lblrg
            // 
            this.lblrg.AutoSize = true;
            this.lblrg.Location = new System.Drawing.Point(382, 83);
            this.lblrg.Name = "lblrg";
            this.lblrg.Size = new System.Drawing.Size(25, 15);
            this.lblrg.TabIndex = 19;
            this.lblrg.Text = "RG:";
            // 
            // txtrg
            // 
            this.txtrg.Location = new System.Drawing.Point(382, 100);
            this.txtrg.Name = "txtrg";
            this.txtrg.Size = new System.Drawing.Size(100, 23);
            this.txtrg.TabIndex = 20;
            // 
            // lbldatanascimento
            // 
            this.lbldatanascimento.AutoSize = true;
            this.lbldatanascimento.Location = new System.Drawing.Point(505, 81);
            this.lbldatanascimento.Name = "lbldatanascimento";
            this.lbldatanascimento.Size = new System.Drawing.Size(117, 15);
            this.lbldatanascimento.TabIndex = 21;
            this.lbldatanascimento.Text = "Data de Nascimento:";
            // 
            // txtdatanascimento
            // 
            this.txtdatanascimento.Location = new System.Drawing.Point(505, 102);
            this.txtdatanascimento.Multiline = true;
            this.txtdatanascimento.Name = "txtdatanascimento";
            this.txtdatanascimento.Size = new System.Drawing.Size(117, 23);
            this.txtdatanascimento.TabIndex = 22;
            // 
            // lblpais
            // 
            this.lblpais.AutoSize = true;
            this.lblpais.Location = new System.Drawing.Point(645, 82);
            this.lblpais.Name = "lblpais";
            this.lblpais.Size = new System.Drawing.Size(89, 15);
            this.lblpais.TabIndex = 23;
            this.lblpais.Text = "Nome dos Pais:";
            // 
            // txtpais
            // 
            this.txtpais.Location = new System.Drawing.Point(645, 102);
            this.txtpais.Multiline = true;
            this.txtpais.Name = "txtpais";
            this.txtpais.Size = new System.Drawing.Size(189, 35);
            this.txtpais.TabIndex = 24;
            // 
            // lblemail
            // 
            this.lblemail.AutoSize = true;
            this.lblemail.Location = new System.Drawing.Point(13, 207);
            this.lblemail.Name = "lblemail";
            this.lblemail.Size = new System.Drawing.Size(44, 15);
            this.lblemail.TabIndex = 25;
            this.lblemail.Text = "E-mail:";
            // 
            // txtemail
            // 
            this.txtemail.Location = new System.Drawing.Point(13, 226);
            this.txtemail.Name = "txtemail";
            this.txtemail.Size = new System.Drawing.Size(100, 23);
            this.txtemail.TabIndex = 26;
            // 
            // lblsenha
            // 
            this.lblsenha.AutoSize = true;
            this.lblsenha.Location = new System.Drawing.Point(140, 207);
            this.lblsenha.Name = "lblsenha";
            this.lblsenha.Size = new System.Drawing.Size(42, 15);
            this.lblsenha.TabIndex = 27;
            this.lblsenha.Text = "Senha:";
            // 
            // txtsenha
            // 
            this.txtsenha.Location = new System.Drawing.Point(140, 226);
            this.txtsenha.Name = "txtsenha";
            this.txtsenha.Size = new System.Drawing.Size(100, 23);
            this.txtsenha.TabIndex = 28;
            // 
            // btncadastrar
            // 
            this.btncadastrar.Location = new System.Drawing.Point(13, 304);
            this.btncadastrar.Name = "btncadastrar";
            this.btncadastrar.Size = new System.Drawing.Size(197, 23);
            this.btncadastrar.TabIndex = 29;
            this.btncadastrar.Text = "Cadastrar";
            this.btncadastrar.UseVisualStyleBackColor = true;
            // 
            // Frmnovousuario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(868, 450);
            this.Controls.Add(this.btncadastrar);
            this.Controls.Add(this.txtsenha);
            this.Controls.Add(this.lblsenha);
            this.Controls.Add(this.txtemail);
            this.Controls.Add(this.lblemail);
            this.Controls.Add(this.txtpais);
            this.Controls.Add(this.lblpais);
            this.Controls.Add(this.txtdatanascimento);
            this.Controls.Add(this.lbldatanascimento);
            this.Controls.Add(this.txtrg);
            this.Controls.Add(this.lblrg);
            this.Controls.Add(this.txtCPF);
            this.Controls.Add(this.lblcpf);
            this.Controls.Add(this.txtcountry);
            this.Controls.Add(this.lblCountry);
            this.Controls.Add(this.txtestado);
            this.Controls.Add(this.lblestado);
            this.Controls.Add(this.txtcidade);
            this.Controls.Add(this.lblcidade);
            this.Controls.Add(this.txtbairro);
            this.Controls.Add(this.lblbairro);
            this.Controls.Add(this.txtnumero);
            this.Controls.Add(this.lbnumero);
            this.Controls.Add(this.txtrua);
            this.Controls.Add(this.lblrua);
            this.Controls.Add(this.txttelefone);
            this.Controls.Add(this.lbltelefone);
            this.Controls.Add(this.txtnome);
            this.Controls.Add(this.lblnome);
            this.Controls.Add(this.label1);
            this.Name = "Frmnovousuario";
            this.Text = "Frmnovousuario";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblnome;
        private System.Windows.Forms.TextBox txtnome;
        private System.Windows.Forms.Label lbltelefone;
        private System.Windows.Forms.TextBox txttelefone;
        private System.Windows.Forms.Label lblrua;
        private System.Windows.Forms.TextBox txtrua;
        private System.Windows.Forms.Label lbnumero;
        private System.Windows.Forms.TextBox txtnumero;
        private System.Windows.Forms.Label lblbairro;
        private System.Windows.Forms.TextBox txtbairro;
        private System.Windows.Forms.Label lblcidade;
        private System.Windows.Forms.TextBox txtcidade;
        private System.Windows.Forms.Label lblestado;
        private System.Windows.Forms.TextBox txtestado;
        private System.Windows.Forms.Label lblCountry;
        private System.Windows.Forms.TextBox txtcountry;
        private System.Windows.Forms.Label lblcpf;
        private System.Windows.Forms.TextBox txtCPF;
        private System.Windows.Forms.Label lblrg;
        private System.Windows.Forms.TextBox txtrg;
        private System.Windows.Forms.Label lbldatanascimento;
        private System.Windows.Forms.TextBox txtdatanascimento;
        private System.Windows.Forms.Label lblpais;
        private System.Windows.Forms.TextBox txtpais;
        private System.Windows.Forms.Label lblemail;
        private System.Windows.Forms.TextBox txtemail;
        private System.Windows.Forms.Label lblsenha;
        private System.Windows.Forms.TextBox txtsenha;
        private System.Windows.Forms.Button btncadastrar;
    }
}